﻿<?php
	class Model
	{	
		private $arr = array('%TITLE%' => 'FORMA', 
						 '%ERROR%' => '',
						 '%DATA%' => '', 
						 '%NAME%' => '',
						 '%MAIL%' => '',
						 '%SUBJECT%' => '',
						 '%MSG%' => '',
						 '%SELECT%' => '<option value="Default" selected>Select something ...</option>
										<option value="Item 1">Item 1</option>
										<option value="Item 2">Item 2</option>
										<option value="Item 3">Item 3</option>');
		private $admMail;
						 
		public function __construct($aMail)
		{
			$this->admMail = $aMail;
		}
		
		public function getArray()
		{
			return $this->arr;
		}
		
		public function checkForm()
		{
			$flag = true;
			foreach ($_POST as $key => $value)
			{
				$$key = trim(htmlspecialchars($_POST[$key]));
			}
			if( !empty($name) )
			{
				$this->arr['%NAME%'] = $name;
				$this->arr['%DATA%'] = $name . '<br />';
			}
			else
			{
				$this->arr['%ERROR%'] = 'Field name empty<br />';
				$flag = false;
			}
			if( !empty($email) && preg_match("/^\w+@[a-zA-Z_]+?\.[a-zA-Z]{2,3}$/u",$email))
			{
				$this->arr['%MAIL%'] = $email;
				$this->arr['%DATA%'] .= $email . '<br />';
			}
			else
			{
				$this->arr['%ERROR%'] .= 'Field email error<br />';
				$flag = false;
			}
			if( 'Default' != $subject)
			{
				$this->arr['%SUBJECT%'] = $subject;
				$this->arr['%DATA%'] .= $subject . '<br />';
				$this->arr['%SELECT%'] = "<option value='Default'>Select something ...</option>";
					
					if ( 'Item 1' == $subject)
					{
						$this->arr['%SELECT%'] .= "<option value=". $subject . " selected>$subject</option>";
					}
					else 
					{
						$this->arr['%SELECT%'] .= "<option value=" . $subject . ">$subject</option>";
					}
					
					if ( 'Item 2' == $subject)
					{
						$this->arr['%SELECT%'] .= "<option value='Item 2' selected>Item 2</option>";
					}
					else 
					{
						$this->arr['%SELECT%'] .= "<option value='Item 2'>Item 2</option>";
					}
					if ( 'Item 3' == $subject)
					{
						$this->arr['%SELECT%'] .= "<option value='Item 3' selected>Item 3</option>";
					}
					else 
					{
						$this->arr['%SELECT%'] .= "<option value='Item 3'>Item 3</option>";
					}
				
			}
			else
			{
				$this->arr['%ERROR%'] .= 'Select something field subject<br />';
				$flag = false;
			}
			if( !empty($msg))
			{
				$this->arr['%MSG%'] = $msg;
				$this->arr['%DATA%'] .= $msg . '<br />';
			}
			else
			{
				$this->arr['%ERROR%'] .= 'Field message empty<br />';
				$flag = false;
			}
			if ( $flag == true )
			{
				$this->arr['%ERROR%'] = 'MAIL SUCCESS SEND';
				return true;
			}
			else 
			{
				$this->arr['%DATA%'] = '';
				return false;
			}
		}
		
		private function defaultArr()
		{
			foreach( $this->arr as $key => $val )
			{
				if ( '%TITLE%' != $key && '%ERROR%' != $key && '%DATA%' != $key && '%SELECT%' != $key)
					$this->arr[$key] = '';
			}
			$this->arr['%SELECT%'] = '<option value="Default" selected>Select something ...</option>
										<option value="Item 1">Item 1</option>
										<option value="Item 2">Item 2</option>
										<option value="Item 3">Item 3</option>';
		}
		
		public function sendMail()
		{
			$msg = $this->arr['%MSG%'] . "\r\n" .$_SERVER['REMOTE_ADDR'] . "\r\n" . $_SERVER['HTTP_USER_AGENT'];
			$email = $this->arr['%MAIL%'];
			$header = 'Content-type:text/plain; Charset=utf-8' . "\r\n". 'From: ' . $email . "\r\n";    
			mail($this->admMail, $this->arr['%SUBJECT%'], $msg, $header);
			$this->defaultArr();
		}
		

	}