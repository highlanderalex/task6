﻿<?php
	class View
	{
		private $forRender;
		private $file;
		
		public function __construct($template)
		{
			if( file_exists($template) && is_readable($template) && is_writable($template) )
			{
				$this->file = file_get_contents($template);
			}
			else
			{
				exit('TEMPLATE NOT FOUND');
			}
		}
		
		public function addToReplace($mArr)
		{
			foreach( $mArr as $key => $val )
			{
				$this->forRender[$key] = $val;
			}
		}
		
		public function templateRender()
		{
			foreach( $this->forRender as $key => $val )
			{
				$this->file = str_replace($key, $val, $this->file);
			}
			echo $this->file;
		}
		
	}