﻿<?php
	define("TEMPLATES", "templates/index.php");
	define("ADMMAIL", "admin@admin.com");
?>